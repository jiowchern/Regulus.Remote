﻿using Regulus.Game;

namespace VGame.Project.FishHunter.Formula.ZsFormula.Data
{
	internal class ScoreOddsTable : ChancesTable<int>
	{
		public ScoreOddsTable(Data[] datas)
			: base(datas)
		{
		}
	}
}
