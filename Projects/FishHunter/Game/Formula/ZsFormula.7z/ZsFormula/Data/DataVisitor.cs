﻿using System.Collections.Generic;
using System.Linq;

using Regulus.Utility;

using VGame.Project.FishHunter.Common.Data;

namespace VGame.Project.FishHunter.Formula.ZsFormula.Data
{
	public class DataVisitor
	{
		public FormulaPlayerRecord PlayerRecord { get; private set; }

		public FishFarmData Farm { get; private set; }

		public FarmDataRoot.BlockNode.BLOCK_NAME FocusBlockName { get; set; }

		public class TreasureKind
		{
			public enum KIND
			{
				RANDOM,
				CERTAIN,
				COUNT,
			}

			public KIND Kind;

			public List<WEAPON_TYPE> Treasures { get; set; }
		}

		public List<TreasureKind> Treasures;

		public List<RandomData> RandomDatas { get; }

		public DataVisitor(FishFarmData fish_farm, FormulaPlayerRecord formula_player_record, List<RandomData> random)
		{
			RandomDatas = random;

			Farm = fish_farm;
			PlayerRecord = formula_player_record;

			Treasures = new List<TreasureKind>
			{
				new TreasureKind
				{
					Kind = TreasureKind.KIND.RANDOM,
					Treasures = new List<WEAPON_TYPE>()
				},
				new TreasureKind
				{
					Kind = TreasureKind.KIND.CERTAIN,
					Treasures = new List<WEAPON_TYPE>()
				},
			};
		}

		public IRandom FindIRandom(RandomData.RULE rule_type, int index)
		{
			return RandomDatas.Find(x => x.RandomType == rule_type)
							.Randoms.ElementAt(index);
		}
	}
}
