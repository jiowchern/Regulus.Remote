﻿using System.Collections.Generic;
using System.Linq;

using VGame.Project.FishHunter.Common.Data;

namespace VGame.Project.FishHunter.Formula.ZsFormula.Rule.Weapon
{
	/// <summary>
	///     皮卡丘
	/// </summary>
	public class ThunderBomb
	{
		private IEnumerable<RequsetFishData> _GetResult(IEnumerable<RequsetFishData> fishs)
		{
			// 只电10倍以上的鱼
			var filter1 = from fish in fishs
						where fish.FishOdds >= 10
						select fish;

			// 最多电15只鱼
			var filter2 = new List<RequsetFishData>();

			foreach(var t in filter1.TakeWhile(t => filter2.Count <= 15))
			{
				filter2.Add(t);
			}

			// 最多250倍
			var filter3 = new List<RequsetFishData>();

			foreach(var t in filter2.Where(t => filter3.Sum(x => x.FishOdds) + t.FishOdds <= 250))
			{
				filter3.Add(t);
			}

			return filter3;
		}

		public RequsetFishData[] Process(IEnumerable<RequsetFishData> fishs)
		{
			return _GetResult(fishs).ToArray();
		}
	}
}
