using VGame.Project.FishHunter.Common.Data;

namespace VGame.Project.FishHunter.Formula.ZsFormula.Rule.Weapon
{
	/// <summary>
	///     �B�z�U�تZ���ϥγW�h
	/// </summary>
	public class SpecialWeaponSelector
	{
		private readonly HitRequest _HitRequest;

		public SpecialWeaponSelector(HitRequest request)
		{
			_HitRequest = request;
		}

		public RequsetFishData[] Run()
		{
			// Provider.Weaon(WEAPON_TYPE).Process(_HitRequest.FishDatas);
			switch(_HitRequest.WeaponData.WeaponType)
			{
				case WEAPON_TYPE.SCREEN_BOMB:
					return new ScreenBomb().Process(_HitRequest.FishDatas);
				case WEAPON_TYPE.THUNDER_BOMB:
					return new ThunderBomb().Process(_HitRequest.FishDatas);
			}

			return _HitRequest.FishDatas;
		}
	}
}
