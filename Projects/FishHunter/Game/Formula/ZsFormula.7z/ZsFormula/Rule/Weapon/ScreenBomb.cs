using System.Collections.Generic;
using System.Linq;

using VGame.Project.FishHunter.Common.Data;

namespace VGame.Project.FishHunter.Formula.ZsFormula.Rule.Weapon
{
	public class ScreenBomb
	{
		// : Provider<ScreenBomb>
		private IEnumerable<RequsetFishData> _GetResult(IEnumerable<RequsetFishData> fishs)
		{
			var t = from fish in fishs
					where fish.FishType < FISH_TYPE.SPECIAL_FREEZE_BOMB
					select fish;

			return t;
		}

		public RequsetFishData[] Process(IEnumerable<RequsetFishData> fishs)
		{
			return _GetResult(fishs).ToArray();
		}
	}

	/*
		new WeaponPower(WEAPON_TYPE.SUPER_BOMB, 250), 
				new WeaponPower(WEAPON_TYPE.ELECTRIC_NET, 150 / 15), 
				new WeaponPower(WEAPON_TYPE.FREE_POWER, 1), 
				new WeaponPower(WEAPON_TYPE.SCREEN_BOMB, 80), 
				new WeaponPower(WEAPON_TYPE.THUNDER_BOMB, 150), 
				new WeaponPower(WEAPON_TYPE.FIRE_BOMB, 120 / 15), 
				new WeaponPower(WEAPON_TYPE.DAMAGE_BALL, 200 / 15), 
				new WeaponPower(WEAPON_TYPE.OCTOPUS_BOMB, 200), 
				new WeaponPower(WEAPON_TYPE.BIG_OCTOPUS_BOMB, 10000)
	*/
}
