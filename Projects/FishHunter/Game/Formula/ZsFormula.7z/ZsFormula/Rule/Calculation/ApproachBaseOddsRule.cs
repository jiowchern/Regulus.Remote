﻿using VGame.Project.FishHunter.Formula.ZsFormula.Data;

namespace VGame.Project.FishHunter.Formula.ZsFormula.Rule.Calculation
{
	public class ApproachBaseOddsRule
	{
		private const int _CheckNumbers = 10000;

		private readonly DataVisitor _Visitor;

		public ApproachBaseOddsRule(DataVisitor visitor)
		{
			_Visitor = visitor;
		}

		/// <summary>
		///     NowBaseOdds 趨近 SetBaseOdds
		/// </summary>
		public void Run()
		{
			if(_Visitor.Farm.NowBaseOdds > _Visitor.Farm.BaseOdds)
			{
				_ChangeNowBaseOdds(-1);
			}
			
			if(_Visitor.Farm.NowBaseOdds < _Visitor.Farm.BaseOdds)
			{
				_ChangeNowBaseOdds(1);
			}
		}

		private void _ChangeNowBaseOdds(int value)
		{
			if (_Visitor.Farm.Record.FireCount % _CheckNumbers == 0)
			{
				_Visitor.Farm.NowBaseOdds += value;
			}
		}
	}
}
