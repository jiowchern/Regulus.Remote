using System.Collections.Generic;
using System.Linq;

using VGame.Project.FishHunter.Common.Data;
using VGame.Project.FishHunter.Formula.ZsFormula.Data;

namespace VGame.Project.FishHunter.Formula.ZsFormula.Rule.Calculation
{
	/// <summary>
	///     �ˬd�H���D��A�@�o�l�u�ˬd�@��
	/// </summary>
	public class RandomTreasureRule
	{
		private readonly DataVisitor _DataVisitor;

		private readonly List<WEAPON_TYPE> _GotTreasures;

		public RandomTreasureRule(DataVisitor data_visitor)
		{
			_DataVisitor = data_visitor;
			_GotTreasures = new List<WEAPON_TYPE>();
		}

		public void Run()
		{
			_GetTreasure();

			_SaveRandomTreasureForPlayer();

			_SaveTreasureForFarm();

			var target = _DataVisitor.Treasures.Find(x => x.Kind == DataVisitor.TreasureKind.KIND.RANDOM)
			.Treasures;

			target.Clear();
			target.AddRange(_GotTreasures);
		}

		private void _GetTreasure()
		{
			var spec = _DataVisitor.Farm.FindDataRoot(_DataVisitor.FocusBlockName, FarmDataRoot.BufferNode.BUFFER_NAME.SPEC);

			var list = new List<WEAPON_TYPE>();

			var randomWeapons = new SpecialWeaponRateTable().WeaponRates;

			// �p�⳽�������_
			foreach(var t in randomWeapons)
			{
				var rate = randomWeapons.Find(x => x.WeaponType == t.WeaponType)
										.Rate;

				long gate = (0x0FFFFFFF / rate / randomWeapons.Count) * spec.Buffer.Rate;

				gate = gate / 1000;

				if(spec.TempValueNode.HiLoRate >= 0)
				{
					gate *= 2;
				}

				if(spec.TempValueNode.HiLoRate < -200)
				{
					gate /= 2;
				}

				var randomValue = _DataVisitor.FindIRandom(RandomData.RULE.CHECK_TREASURE, 0)
											.NextInt(0, 0x10000000);
				if(randomValue >= gate)
				{
					continue;
				}

				// �b�o�������W�o�쪺�D��
				list.Add(t.WeaponType);
			}

			_OrderByWeapon(list);
		}

		private void _OrderByWeapon(IEnumerable<WEAPON_TYPE> list)
		{
			var weaponrandomValue = _DataVisitor.FindIRandom(RandomData.RULE.CHECK_TREASURE, 1)
												.NextFloat(0, 1);

			var randomWeapon = list.OrderBy(x => weaponrandomValue)
									.FirstOrDefault();

			if(randomWeapon != WEAPON_TYPE.INVALID)
			{
				_GotTreasures.Add(randomWeapon);
			}
		}

		private void _SaveTreasureForFarm()
		{
			var randomTreasures = _DataVisitor.Farm.Record.RandomTreasures;

			_SaveTreasureHistory(randomTreasures.ToList());
		}

		private void _SaveRandomTreasureForPlayer()
		{
			var randomTreasures = _DataVisitor.PlayerRecord.FindFarmRecord(_DataVisitor.Farm.FarmId)
											.RandomTreasures;

			_SaveTreasureHistory(randomTreasures.ToList());
		}

		private void _SaveTreasureHistory(ICollection<TreasureRecord> records)
		{
			foreach(var t in _GotTreasures)
			{
				var r = records.FirstOrDefault(x => x.WeaponType == t);

				if(r == null)
				{
					r = new TreasureRecord
					{
						WeaponType = t, 
						Count = 0
					};

					records.Add(r);
				}

				r.Count++;
			}
		}
	}
}
