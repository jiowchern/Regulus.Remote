using System;
using System.Collections.Generic;
using System.Linq;

using VGame.Project.FishHunter.Common.Data;
using VGame.Project.FishHunter.Formula.ZsFormula.Data;

namespace VGame.Project.FishHunter.Formula.ZsFormula.Rule.Calculation
{
	/// <summary>
	///     �ˬd�����D��
	/// </summary>
	public class CertainTreasureRule
	{
		protected DataVisitor _DataVisitor;

		protected RequsetFishData _FishData;

		protected List<WEAPON_TYPE> _GotTreasures;

		public CertainTreasureRule(DataVisitor data_visitor, RequsetFishData fish_data)
		{
			_DataVisitor = data_visitor;
			_FishData = fish_data;

			_GotTreasures = new List<WEAPON_TYPE>();
		}

		public void Run()
		{
			GetTreasure();

			_SaveTreasureForPlayer();

			_SaveTreasureForFarm();

			var target = _DataVisitor.Treasures.Find(x => x.Kind == DataVisitor.TreasureKind.KIND.CERTAIN)
						.Treasures;

			target.Clear();

			target.AddRange(_GotTreasures);
		}

		public void GetTreasure()
		{
			if(_FishData.FishType >= FISH_TYPE.TROPICAL_FISH && _FishData.FishType <= FISH_TYPE.SPECIAL_EAT_FISH_CRAZY)
			{
				_GotTreasures.Add(_FishData.FishStatus == FISH_STATUS.KING ? WEAPON_TYPE.KING : WEAPON_TYPE.INVALID);
			}
			else
			{
				var certainWeapons = FishTreasure.Get()
												.Find(x => x.FishType == _FishData.FishType)
												.CertainWeapons;

				foreach(var weapon in certainWeapons)
				{
					_GotTreasures.Add(weapon);
				}
			}
		}

		private void _SaveTreasureForPlayer()
		{
			var fishHitRecords = _DataVisitor.PlayerRecord.FindFarmRecord(_DataVisitor.Farm.FarmId)
											.FishHits;

			_SaveTreasureHistory(fishHitRecords);
		}

		private void _SaveTreasureForFarm()
		{
			var fishHitRecords = _DataVisitor.Farm.Record.FishHits;

			_SaveTreasureHistory(fishHitRecords);
		}

		private void _SaveTreasureHistory(IEnumerable<FishHitRecord> fish_hit_records)
		{
			var record = fish_hit_records.FirstOrDefault(x => x.FishType == _FishData.FishType);

			if(record == null)
			{
				return;
			}

			var list = record.TreasureRecords.ToList();

			foreach(var treasure in _GotTreasures)
			{
				var d = list.FirstOrDefault(x => x.WeaponType == treasure);
				if(d == null)
				{
					d = new TreasureRecord(treasure);
					list.Add(d);
				}

				d.Count++;
			}

			record.TreasureRecords = list.ToArray();
		}
	}
}
